INSERT INTO agenda_db.evento 
(titulo,
fecha_inicio,
hora_inicio,
fecha_fin,
hora_fin,
dia_completo,
user_id) 
VALUES 
('Primer tarea',
'2020-11-15 00:00:00',
'12:00:00',
'2020-11-17 00:00:00',
'14:00:00',
0,
9);